<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Models\Customer;
use App\Models\UserProfile;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\CustomerProfile;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class LoginRegisterController extends Controller
{
    //
    public function login()
    {
        session(['url.intended' => url()->previous()]);
        return view('auth.login');
    }
    public function register()
    {
        return view('auth.register');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|confirmed|min:8',
        ]);

        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator)->withInput();
            // throw ValidationException::withMessages(['Email Already Exists!']);
        }
        else {
            // Register the new user or whatever.
            $data = $request->all();
            $check = $this->create($data);

            return redirect("/")->withSuccess('have signed-in');
        }
    }


    public function create(array $data)
    {
        return Customer::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password'])
        ]);
    }

    public function authenticate(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        $credentials = $request->only('email', 'password');
        $successMessage = session('success');
        if (Auth::guard('customer')->attempt($credentials)) {
            // Get the authenticated user

            $user = null;
            $data = null;

            if (Auth::guard('customer')->check()) {
                // User authenticated via 'customer' guard
                $user = Auth::guard('customer')->user();
            }
            $previousUrl = session('url.intended');
            if ($previousUrl && Str::contains($previousUrl, 'cart')) {
                if ($user->profile) {

                    session(['url.intended' => url('address')]);
                    return redirect()->intended('address');
                } else {

                    $data = ($user instanceof Customer) ? Customer::find($user->id) : User::find($user->id);
                    return view('orders.billingdetails', compact('data'));
                }
            } else {

                $address = ($user instanceof Customer) ? Customer::find($user->id) : User::find($user->id);
                return view('auth.profile', compact('address'));
            }

        }

        return redirect()->route('login')->with('error', 'Invalid credentials');
    }
     public function checkout()
    {
        if (Auth::guard('customer')->check() ) {
            // Get the authenticated user
            $user = Auth::guard('customer')->user();


        if ($user && $user->profile) {
                // If a record exists, redirect to the billing page
                return redirect('/address');
            } else {
                $data = Customer::find($user->id);
                return view('orders.billingdetails', compact('data'));
            }
        }
    }

    public function address()
    {
        if (Auth::guard('customer')->check() ) {
            // Get the authenticated user
            $user = Auth::guard('customer')->user();
            $address = CustomerProfile::with('customer')->where('customer_id', $user->id)->first();
        }

        return view('orders.address', compact('address'));

    }
    public function get_UserProfile(Request $request)
    {


        $request->validate([

            'mobile' => 'required',
            'door_no' => 'required',
            'street' => 'required',
            'pincode' => 'required',
            'area' => 'required',
            'city' => 'required',
            'state' => 'required',
            'country' => 'required',
            'GST' => 'required|regex:/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/',


        ]);

        $data = $request->all();
        CustomerProfile::create($data);

        return redirect()->route('address');

    }
     public function profile(){
        if (Auth::guard('customer')->check()) {
            // Get the authenticated user
            $user = Auth::guard('customer')->user();
            if ($user->profile) {
                $address = CustomerProfile::with('customer')->where('customer_id', $user->id)->first();
                return view('auth.profile', compact('address'));
            } else {
                $data = Customer::find($user->id);
                // dd($address);
                return view('auth.userprofile', compact('data'));
            }
        }

    }
    public function update_userdetails(Request $request){

        // $id = $request->only('','mobile_no', 'GST');
        $user = CustomerProfile::find($request->customer_id);

        // Check if the user exists
        if (!$user) {
            abort(404); // Or handle as appropriate
        }
    // Modify user details
    $user->mobile = $request->input('mobile');
    $user->GST = $request->input('GST');
    $user->save();
    return redirect()->back()->with('success', 'User details updated successfully');


    }

    public function logout()
    {
        Session::flush();
        Auth::logout();

        return Redirect('/');
    }


}
